==================================
#  PHP Navigator 3.2		
#  9:36 PM; August 16, 2006			
#  http://navphp.sourceforge.net		
==================================

  OEdit integration (IE & FF only) for PHP Navigator 3.2
  OEdit is a WYSIWYG (visual) html editor. 

Credits
-------
OEdit Ver. 3.6 - � 2004 Peter Andreas Harteg - http : // www.harteg.dk

------------------------------------------------------------------------ 
Contact: cyril2net@yahoo.com
Web: 'http://navphp.sourceforge.net'
